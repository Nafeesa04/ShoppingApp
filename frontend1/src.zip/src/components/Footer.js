const Footer = () => {
    return <footer>© 2024 Your Store. All rights reserved.</footer>;
};

export default Footer;