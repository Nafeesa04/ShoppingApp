const Header = () => {
    return <header>ShopEase</header>;
};

export default Header;